﻿using System;
using System.Collections.Generic;

namespace ClassMarksAndStudents
{
    public class ClassPortal
    {
        //Класс студентов.
        public class Students
        {
            public int year { get; set; }
            public int group { get; set; }
            public string fio { get; set; }
            public Students(int y, int g, string FIO)
            {
                year = y;
                group = g;
                fio = FIO;
            }
        }
        //Класс оценок.
        public class Mark
        {
            public DateTime Date { get; set; }
            public string Estimation { get; set; }
            Students Student { get; set; }
            public Mark(DateTime date, string estimation, Students students)
            {
                Date = date;
                Estimation = estimation;
                Student = students;
            }
        }
        //Задание 1.
        //Генерация оценок, посещаемости на 10 дней вперед, начиная с текущей даты со списком переданных студентов.
        public List<Mark> GetMarks(DateTime now, List<Students> students)
        {
            string[] estimation = { "2", "3", "4", "5", "п", "н", "б" };
            List<Mark> marks = new List<Mark>();
            foreach (Students student in students)
            {
                marks.Add(new Mark
                    (
                        now,
                        estimation[new Random().Next(0, estimation.Length)],
                        student)
                    );
            }
            return marks;
        }
        //Задание 2.
        //Вычисление среднего арифметического значения оценки в меньшую сторону обращение

        public double MinAVG(string[] marks)
        {
            int j = 0;
            int summ = 0;
            foreach (string mark in marks)
            {
                if (int.TryParse(mark, out int estimation))
                {
                    summ += estimation;
                    j++;
                }
            }
            return (double)Math.Floor((decimal)(summ / i));
        }
        //Задание 3.
        //Вычисление количество прогулов за месяц за период обращение по прогулам.

        public int[] GetCountTruancy(List<Mark> marks)
        {
            int[] count = new int[12];

            foreach (Mark mark in marks)
            {
                if (mark.Estimation == "н")
                {
                    count[mark.Date.Month - 1] = +1;
                }
            }
            return count;
        }
        //Задание 4.
        //Вычисление количество прогулов за месяц за период обращение по болезни.
        public int[] GetCountTruancy1(List<Mark> marks)
        {
            int[] count = new int[12];

            foreach (Mark mark in marks)
            {
                if (mark.Estimation == "б")
                {
                    count[mark.Date.Month - 1] = +1;
                }
            }
            return count;
        }
        //Задание 5.
        //Генерация номера студенческого билета в 
        public string GetStudNumber(Students students)
        {
            string[] FIO = students.fio.Split();
            return $"{students.year.ToString("yyyy")}.{students.group}.{FIO[0][0]}{FIO[1][0]}{FIO[2][0]}";
        }



    }
}